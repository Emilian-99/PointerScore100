# PointerScore 100

Produktionsreife statische Landingpage fuer PointerScore 100.

## Struktur

- index.html
- style.css
- script.js
- assets/logo.svg
- assets/favicon.svg
- assets/icons/
- pages/impressum.html
- pages/kontakt.html
- pages/datenschutz.html

## Nutzung

Die Website nutzt nur HTML, CSS und Vanilla JavaScript. Sie kann direkt ueber GitHub Pages veroeffentlicht werden.

## Hinweise

- Rechtstexte sind Platzhalter und sollten vor Veröffentlichung geprüft werden.
- Das Formular ist statisch und speichert keine Daten serverseitig.
- Google Fonts ist die einzige externe Ressource.
