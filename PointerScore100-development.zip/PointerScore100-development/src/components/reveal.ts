export function initReveal() {
  const elements = document.querySelectorAll<HTMLElement>(".reveal");
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) { entry.target.classList.add("is-visible"); observer.unobserve(entry.target); }
    });
  }, { threshold: 0.16 });
  elements.forEach((element, index) => { element.style.transitionDelay = String(Math.min(index % 5, 4) * 60) + "ms"; observer.observe(element); });
}
