# Supabase

Migrationen und spätere Edge Functions werden in diesem Ordner versioniert.
